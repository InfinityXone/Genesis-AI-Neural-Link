#!/bin/bash
echo 'Deploying Genesis Swarm to Cloud Run and Vercel...'