CREATE TABLE rosetta_memory (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  embedding VECTOR(1536),
  content TEXT,
  tags TEXT[],
  source TEXT,
  importance FLOAT DEFAULT 0.5,
  created_at TIMESTAMPTZ DEFAULT now()
);